#ifndef USERINFO_H
#define USERINFO_H
#include <QString>

class UserInfo
{
public:
    QString Dept;
    QString Uname;
    QString Usex;
    QString UCon;
public:
    UserInfo();
};

#endif // USERINFO_H
