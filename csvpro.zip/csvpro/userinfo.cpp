#include "userinfo.h"

UserInfo::UserInfo()
{


}
